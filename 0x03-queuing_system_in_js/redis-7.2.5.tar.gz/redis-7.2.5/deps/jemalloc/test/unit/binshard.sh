#!/bin/sh

export MALLOC_CONF="narenas:1,bin_shards:1-160:16|129-512:4|256-256:8"
